﻿using BlazorServerAuthenticationAndAuthorization.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorServerAuthenticationAndAuthorization.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        public DbSet<Person> SPersons { get; set; }
        public DbSet<imageinfo> Simageinfos { get; set; }
    }
}
