﻿using System.Drawing;
//using System.Drawing.Common;
namespace BlazorServerAuthenticationAndAuthorization.Data
{
    public class FileUpload
    {
        public static void ByteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image image = Image.FromStream(ms);
            //System.Drawing.SizeF
            //var returnImage = Image.from(ms);

        }
    }
}
