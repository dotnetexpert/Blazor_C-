﻿using BlazorServerAuthenticationAndAuthorization.Models;

namespace BlazorServerAuthenticationAndAuthorization.Interfaces
{
    public interface IimageService
    {
        Task<IEnumerable<imageinfo>> GetImageList();
        Task<imageinfo> Createimage(imageinfo imageinfo);
        Task Updateimage(imageinfo imageinfo);
        Task Deleteimage(imageinfo imageinfo);

    }
}
