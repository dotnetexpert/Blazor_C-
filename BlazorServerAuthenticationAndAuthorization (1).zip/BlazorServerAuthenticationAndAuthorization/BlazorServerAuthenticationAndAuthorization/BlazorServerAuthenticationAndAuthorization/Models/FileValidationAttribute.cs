﻿namespace BlazorServerAuthenticationAndAuthorization.Models
{
    public class FileValidationAttribute : Attribute
    {
        public FileValidationAttribute(string[] allowedExtensions)
        {
            allowedExtensions = allowedExtensions;
        }
    }
}