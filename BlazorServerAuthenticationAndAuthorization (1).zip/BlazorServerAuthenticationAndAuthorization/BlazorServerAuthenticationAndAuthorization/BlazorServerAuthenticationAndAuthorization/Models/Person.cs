﻿using Microsoft.AspNetCore.Components.Forms;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BlazorServerAuthenticationAndAuthorization.Models
{
    public class Person
    {
        [Required]
        public int Id { get; set; }
        [Required]
        [NotMapped]
        [FileValidation(new[] { ".png", ".jpg" })]
        public IBrowserFile[] Picture { get; set; }
    }
}
