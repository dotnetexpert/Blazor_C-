﻿namespace BlazorServerAuthenticationAndAuthorization.Models
{
    public class imageinfo
    {
        public int Id { get; set; }
        public string? base64 { get; set; }
        public string? State { get; set; }
        public string? ImagePath { get; set; }
        public bool IsSelected { get; set; }
        public bool IsDeleted { get; set; }
    }
}
