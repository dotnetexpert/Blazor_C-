﻿using Microsoft.AspNetCore.Components;

namespace BlazorServerAuthenticationAndAuthorization.Pages
{
    public class ConfirmBase : ComponentBase
    {
        [Parameter]
        public bool ShowConfirmation { get; set; }

        [Parameter]
        public string ConfirmationTitle { get; set; } = "Confirm Delete";
        [Parameter]
        public string ButtonText { get; set; } = string.Empty;

        [Parameter]
        public string ConfirmationMessage { get; set; } = "Do you really want to delete these records? This process cannot be undone.";
        [Parameter]
        public int? ImageCount { get; set; }
        public void Show()
        {
            ShowConfirmation = true;
            StateHasChanged();
        }

        [Parameter]
        public EventCallback<bool> ConfirmationChanged { get; set; }

        protected async Task OnConfirmationChange(bool value)
        {
            ShowConfirmation = false;

            await ConfirmationChanged.InvokeAsync(value);
        }
    }
}
