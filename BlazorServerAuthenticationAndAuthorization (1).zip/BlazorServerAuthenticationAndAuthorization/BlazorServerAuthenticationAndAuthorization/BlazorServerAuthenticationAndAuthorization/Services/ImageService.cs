﻿using BlazorServerAuthenticationAndAuthorization.Data;
using BlazorServerAuthenticationAndAuthorization.Interfaces;
using BlazorServerAuthenticationAndAuthorization.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorServerAuthenticationAndAuthorization.Services
{
    public class ImageService : IimageService
    {
        private readonly ApplicationDbContext _context;
        public ImageService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<imageinfo> Createimage(imageinfo imageinfo)
        {
            try
            {

                await _context.Simageinfos.AddAsync(imageinfo);
                await _context.SaveChangesAsync();
                return imageinfo;
            }
            catch (Exception e)
            {
              
                throw;
            }
        }

        public async Task Deleteimage(imageinfo Imageinfo)
        {
            try
            {
                var data = _context.Simageinfos.Find(Imageinfo.Id);
                var res = _context.Simageinfos.Remove(data);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {

            }

        }

        public async Task<IEnumerable<imageinfo>> GetImageList()
        {
            try
            {
                return await _context.Simageinfos.ToListAsync();
            }
            catch
            {
                throw;
            }
        }

        public async Task Updateimage(imageinfo imageinfo)
        {
            _context.Simageinfos.Update(imageinfo);
            await _context.SaveChangesAsync();
        }

    }
}
