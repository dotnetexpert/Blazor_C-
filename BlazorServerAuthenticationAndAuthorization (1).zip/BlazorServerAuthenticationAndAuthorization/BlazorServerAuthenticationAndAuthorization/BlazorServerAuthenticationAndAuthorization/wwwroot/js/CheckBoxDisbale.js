﻿function selects() {
    var ele = document.getElementsByName('chk');
    for (var i = 0; i < ele.length; i++) {
        if (ele[i].type == 'checkbox') {
            if (ele[i].checked == true) {
                ele[i].checked = false;

            }
            else {
                ele[i].checked = true;
            }
        }
    }
}

