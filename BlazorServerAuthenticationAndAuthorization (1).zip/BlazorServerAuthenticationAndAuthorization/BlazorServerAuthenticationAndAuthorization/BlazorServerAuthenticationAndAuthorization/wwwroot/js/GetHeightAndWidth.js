﻿$(window).resize(function ()
{
    var GetHeightWidth = window.innerHeight;
    var finalheight = GetHeightWidth - 220;
    //$("#RepoId").css("height", window.innerWidth + "px");
    $("#mainBox").css("height", finalheight + "px");
  
});
function Repo() {
    var GetHeightWidth = window.innerHeight;
    var finalheight = GetHeightWidth - 220;
    $("#mainBox").css("height", finalheight + "px");
}