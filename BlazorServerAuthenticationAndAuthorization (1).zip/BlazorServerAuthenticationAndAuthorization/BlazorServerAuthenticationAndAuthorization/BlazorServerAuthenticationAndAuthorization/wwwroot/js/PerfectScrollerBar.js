﻿//Scroll hide image
$(window).scroll(function () {
    $(this).scrollTop() > 50 ? $('#scroll').fadeOut() : $('#scroll').fadeIn()
});