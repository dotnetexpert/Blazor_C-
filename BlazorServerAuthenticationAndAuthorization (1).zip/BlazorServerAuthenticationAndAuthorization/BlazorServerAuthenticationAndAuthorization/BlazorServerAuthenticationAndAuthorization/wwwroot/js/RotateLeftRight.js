﻿function rotateimage(e) {
    var angle = ($(e).data('angle') + 90) || 90;
    $(e).css({ 'transform': 'rotate(' + angle + 'deg)' });
    $(e).data('angle', angle);
    //return angle;
    var data = $(e).attr('src');
}