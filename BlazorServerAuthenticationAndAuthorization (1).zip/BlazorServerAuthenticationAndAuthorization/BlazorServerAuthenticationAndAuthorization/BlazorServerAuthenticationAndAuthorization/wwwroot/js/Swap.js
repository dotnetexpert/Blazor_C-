﻿function getsortwithid() {
    var IMG = [];
    $('#sortable li').each(function () {
        IMG.push($(this).attr('data-sortid'));
    });
    return IMG;
}