﻿namespace Visual_Builder.Models
{
    public class Classownername
    {
        public string? CustomerOrder { get; set; }
        public string? CustomerDetails { get; set; }
        public string? ContactInformation { get; set; }
        public string? AddressInformation { get; set; }
        public string? Invoice { get; set; }
        public string? PurchaseOrder { get; set; }
        public string? WorkOrder { get; set; }
    }
    
}
