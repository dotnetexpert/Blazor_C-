﻿namespace Visual_Builder.Models
{
    public class Config
    {
        public List<string> Lists { get; set; }
    }

}
