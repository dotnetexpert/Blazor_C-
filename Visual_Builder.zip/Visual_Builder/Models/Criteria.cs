﻿namespace Visual_Builder.Models
{
    public class Criteria
    {
        public long myID { get; set; } = 0;  //The unique ID of this item, this is auto set by the API, so 0 means new.
        public long stepOwnerID { get; set; } //The ID of the "Step" header this belongs to
        public string? name { get; set; } //The user defined name of this Criteria
        public string? description { get; set; } //The user defined description of this Criteria
        public string? criteriaType { get; set; } //Options: "Can Skip" or "Always Execute"
        public string? criteriaExpression { get; set; } //User entered expression text
        public bool waitForAllPreviousActions { get; set; } //Boolean value
    }
}
