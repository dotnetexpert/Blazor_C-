﻿namespace Visual_Builder.Models
{
    public class VisualBuilderDataSource
    {
        public string? Id { get; set; }
        public string? parentid { get; set; }
        public string? stepOwnerID { get; set; }
        public string? NodeType { get; set; }
        public string? Name { get; set; }
        public string? DirectChilName { get; set; }
        public string? Discription { get; set; }
        public string? Color { get; set; }
        public string? ChartType { get; set; }
        public string? Type { get; set; }
        public string? Orientation { get; set; }
        public int? RotationAngle { get; set; }
        public List<string> Remarks { get; set; }
    }
}
