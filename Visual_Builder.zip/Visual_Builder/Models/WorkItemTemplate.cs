﻿namespace Visual_Builder.Models
{
    public class WorkItemTemplate
    {
        public long myID { get; set; } = 0;  //The unique ID of this item, this is auto set by the API, so 0 means new.
        public long parentActionID { get; set; } //The ID of the Action this WorkItem is directly connected to
        public long stepOwnerID { get; set; } //The ID of the "Step" header this belongs to
        public string? name { get; set; } //The user definedname of this WorkItemTemplate
        public string? description { get; set; } //The user defineddescription of this WorkItemTemplate
        public long criteriaListID { get; set; } //The unique ID of the related "Criteria" item this is using
        public string? workItemType { get; set; } //Options: Communication, Process Change, Group, Survey
        public long stepToBlock { get; set; } //The unique ID of a user selected "Step"  (must be a step that belongs to the same "Step Header")
        public string? templateText { get; set; } //User entered textpublicstringSLAType { get; set; }  //Options: Days, Weeks, Months, Years, None
        public string? slaType { get; set; } //User entered textpublicstringSLAType { get; set; }  //Options: Days, Weeks, Months, Years, None
        public int SLAAmount { get; set; } //An integer value. If "useSLA" is true, this must be greater than 0, of it's false, this must equal 0
        public bool useSLA { get; set; } //boolean value
    }
}
