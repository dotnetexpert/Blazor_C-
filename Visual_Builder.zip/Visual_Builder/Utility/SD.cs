﻿using Visual_Builder.Models;
using static System.Net.WebRequestMethods;

namespace Visual_Builder.Utility
{
    public static class SD
    {
        public static string keyvalue { get; set; } = "qIvRzdhsTA2rDunEoN0HadlWRJ5Ec3h3oxeqPqK6";
        public static string APIBaseUrl = "https://4ntto7xqwe.execute-api.ap-southeast-2.amazonaws.com/Prod";

        //Upsert Step
        public static string PostStepApiPath = APIBaseUrl + "/step";
        public static string GetStepByIdApiPath = APIBaseUrl + "/step/";
        public static string GetAllstepheadersPath = APIBaseUrl + "/step/heads";
        public static string DeletesStepbyIdPath = APIBaseUrl + "/step/";
        public static string GetstepactionlistbyId = APIBaseUrl + "/step/actionlist/";

        //Upsert criteria
        public static string PostcriteriaApiPath = APIBaseUrl + "/criteria";
        public static string GetcriteriabyIDApiPath = APIBaseUrl + "/criteria/";
        public static string DeletescriteriabyIDApiPath = APIBaseUrl + "/criteria/";

        //Upsert an ACTION LIST
        public static string PostActionlistApiPath = APIBaseUrl + "/actionlist";
        public static string GetActionlistByIdApiPath = APIBaseUrl + "/actionlist/";
        public static string DeleteActionlistByIdApiPath = APIBaseUrl + "/actionlist/";

        //Upsert an ACTION ITEM
        public static string PostActionitemApiPath = APIBaseUrl + "/actionitem";
        public static string GetActionitemByIdApiPath = APIBaseUrl + "/actionitem/";
        public static string GetActionitemattachedToActionListByIdApiPath = APIBaseUrl + "/actionitem/actionlist/";
        public static string DeleteActionitemByIdApiPath = APIBaseUrl + "/actionitem/";

        //Upsert a WORK ITEM TEMPLAT
        public static string PostworkitemtemplateApiPath = APIBaseUrl + "/workitemtemplate";
        public static string GetworkitemtemplateByIdApiPath = APIBaseUrl + "/workitemtemplate/";
        public static string DeleteworkitemtemplateByIdApiPath = APIBaseUrl + "/workitemtemplate/";
        public static string GetWorkitemTemplAteattachedToActionItemByIdApiPath = APIBaseUrl + "/workitemtemplate/actionitem/";

        //process
        public static string GetprocessByIdApiPath = APIBaseUrl + "/process/";
        public static string GetAllStepsForTheProcessApiPath = APIBaseUrl + "/process/steps/";
        public static string GetAllCriteriaForTheProcessApiPath = APIBaseUrl + "/process/criteria/";
        public static string GetAllActionlistsForTheProcessApiPath = APIBaseUrl + "/process/actionlists/";
        public static string GetAllActionitemsForTheProcessApiPath = APIBaseUrl + "/process/actionitems/";
        public static string GetAllWorkitemtemplatesForTheProcessApiPath = APIBaseUrl + "/process/workitemtemplates/";

        //Get all Class Owner Names
        public static string GetClassownernamesApiPath = APIBaseUrl + "/config/classownernames";
        public static string GetcriteriatypesApiPath = APIBaseUrl + "/config/criteriatypes";
        public static string GetSlatypesApiPath = APIBaseUrl + "/config/slatypes";


    }
}
