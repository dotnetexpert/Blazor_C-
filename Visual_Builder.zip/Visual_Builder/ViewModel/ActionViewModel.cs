﻿namespace Visual_Builder.ViewModel
{
    public class ActionViewModel
    {
        public long myID { get; set; } = 0;  //The unique ID of this item, this is auto set by the API, so 0 means new.
        public long parentActionListID { get; set; } //The ID of the ActionList this Action is directly connected to
        public long stepOwnerID { get; set; } //The ID of the "Step" header this belongs to
        public string? name { get; set; } //The user definedname of this Action
        public string? description { get; set; } //The user defineddescription of this Action
        public long criteriaListID { get; set; } //The unique ID of the related "Criteria" item this is using
        public int position { get; set; } //The position that this Action is in relation to any other Actions connected to the same "ActionList"
        public IEnumerable<WorkItemTemplateViewModel> DirectworkItemTemplateViews { get; set; }
    }
}
