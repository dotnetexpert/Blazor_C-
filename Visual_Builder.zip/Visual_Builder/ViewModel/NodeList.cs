﻿using Visual_Builder.Models;

namespace Visual_Builder.ViewModel
{
    public class NodeList
    {
         public Step? step { get; set; }
         public ActionList? actionList { get; set; }
         public ActionItem? actionItem { get; set; }
         public  WorkItemTemplate? _workItemTemplate { get; set; }
    }
}
