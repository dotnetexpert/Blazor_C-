﻿using Visual_Builder.Models;

namespace Visual_Builder.ViewModel
{
    public class Process
    {
        public IEnumerable<Step> steps { get; set; }
        public IEnumerable<Criteria> criteria { get; set; }
        public IEnumerable<ActionList> actionLists { get; set; }
        public IEnumerable<ActionItem> actionItems { get; set; }
        public IEnumerable<WorkItemTemplate> workItemTemplates { get; set; }
    }
}
