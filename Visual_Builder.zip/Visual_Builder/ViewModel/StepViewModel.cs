﻿namespace Visual_Builder.ViewModel
{
    public class StepViewModel
    {
        public long myID { get; set; } = 0; //The unique ID of this item, this is auto set by the API, so 0 means new.
        public long parentStepID { get; set; } //The ID of the parent step this Step is directly a child of
        public long stepOwnerID { get; set; } //The ID of the "Step" header this belongs to
        public string? stepOwnerClassName { get; set; }//The name of the owner class -ONLY if the stepType is "Process Head", otherwise blank
        public string? name { get; set; } //The user defined name of this Step
        public string? description { get; set; } //The user defined description of this Step
        public string? stepType { get; set; } //Options: "Process Head" or "Process Step"
        public long criteriaListID { get; set; } //The unique ID of the related "Criteria" item this is using
        public int position { get; set; } //The position this step is in relation to all other steps connected to the same parent "Step"
        public bool stepVisible { get; set; }
        public IEnumerable<ActionListViewModel> DirectactionListViews { get; set; }
    }
}
