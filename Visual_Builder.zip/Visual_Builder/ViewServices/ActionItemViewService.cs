﻿using Visual_Builder.Models;
using Visual_Builder.ViewServices.IViewService;

namespace Visual_Builder.ViewServices
{
    public class ActionItemViewService : ServiceBase<ActionItem>, IActionItemViewService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        public ActionItemViewService(IHttpClientFactory httpClientFactory, IHttpContextAccessor httpContextAccessor) : base(httpClientFactory, httpContextAccessor)
        {
            _httpClientFactory = httpClientFactory;
        }
    }
}
