﻿using Visual_Builder.Models;
using Visual_Builder.ViewServices.IViewService;

namespace Visual_Builder.ViewServices
{
    public class ActionListViewService : ServiceBase<ActionList>, IActionListViewService
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public ActionListViewService(IHttpClientFactory httpClientFactory, IHttpContextAccessor httpContextAccessor) : base(httpClientFactory, httpContextAccessor)
        {
            _httpClientFactory = httpClientFactory;
        }
    }
}
