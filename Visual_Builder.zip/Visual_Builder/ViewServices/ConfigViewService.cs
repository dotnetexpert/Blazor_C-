﻿using Newtonsoft.Json;
using System;
using Visual_Builder.Utility;
using Visual_Builder.ViewServices.IViewService;

namespace Visual_Builder.ViewServices
{
    public class ConfigViewService: IConfigViewService
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public ConfigViewService(IHttpClientFactory httpClientFactory, IHttpContextAccessor httpContextAccessor)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<List<string>> GetAllconfigs(string Url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, Url);
                //request.Headers.Authorization= new AuthenticationHeaderValue(SD.keyvalue);
                request.Headers.Add("x-api-key", SD.keyvalue);
                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.SendAsync(request);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<List<string>>(jsonString);
                }
                return null;
            }
            catch
            {
                return null;
            }
        }
        public async Task<string> GetAsync(string url, int id)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, url + id.ToString());
                request.Headers.Add("x-api-key", SD.keyvalue);

                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.SendAsync(request);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<string>(jsonString);
                }
                return null;
            }
            catch
            {
                return null;
            }

        }
    }
}
