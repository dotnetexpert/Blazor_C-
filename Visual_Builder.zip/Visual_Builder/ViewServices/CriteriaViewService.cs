﻿using Visual_Builder.Models;
using Visual_Builder.ViewServices.IViewService;

namespace Visual_Builder.ViewServices
{
    public class CriteriaViewService : ServiceBase<Criteria>, ICriteriaViewService
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public CriteriaViewService(IHttpClientFactory httpClientFactory, IHttpContextAccessor httpContextAccessor) : base(httpClientFactory, httpContextAccessor)
        {
            _httpClientFactory = httpClientFactory; 
        }
    }
}
