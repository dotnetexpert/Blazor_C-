﻿namespace Visual_Builder.ViewServices.IViewService
{
    public interface IConfigViewService
    {
        Task<List<string>> GetAllconfigs(string Url);
        Task<string> GetAsync(string url, int id);
    }
}
