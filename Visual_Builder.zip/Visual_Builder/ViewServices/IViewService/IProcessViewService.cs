﻿using Visual_Builder.ViewModel;

namespace Visual_Builder.ViewServices.IViewService
{
    public interface IProcessViewService:IServiceBase<Process>
    {
    }
}
