﻿namespace Visual_Builder.ViewServices.IViewService
{
    public interface IServiceBase<T> where T : class
    {
        Task<T?> GetAsync(string url, int id);
        Task<IEnumerable<T>?> GetlistAsync(string url, int id);
        Task<IEnumerable<T>?> GetbyId(string url, int id);
        Task<IEnumerable<T>?> GetAllAsync(string url);
        Task<T> GetAll_Async(string url);
        Task<bool> CreateAsync(string url, T objToCreate);
        Task<bool> UpdateAsync(string url, T objToUpate);
        Task<bool> DeleteAsync(string url, int id);
        Task<IEnumerable<T>?> postAsync(string url, T objToPost);
        Task<bool> UpSert(string url, T objToPost);
    }
}
