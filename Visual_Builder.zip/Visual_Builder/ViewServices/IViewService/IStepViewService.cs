﻿using Visual_Builder.Models;
using Visual_Builder.ViewServices.IViewService;

namespace Visual_Builder.ViewServices.IViewService
{
    public interface IStepViewService:IServiceBase<Step>
    {

    }
}
