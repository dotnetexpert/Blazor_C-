﻿
using Visual_Builder.ViewModel;
using Visual_Builder.ViewServices.IViewService;

namespace Visual_Builder.ViewServices
{
    public class ProcessViewService : ServiceBase<Process>, IProcessViewService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        public ProcessViewService(IHttpClientFactory httpClientFactory, IHttpContextAccessor httpContextAccessor) : base(httpClientFactory, httpContextAccessor)
        {
            _httpClientFactory = httpClientFactory;
        }
    }
}
