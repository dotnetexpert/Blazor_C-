﻿using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;
using Visual_Builder.Utility;
using Visual_Builder.ViewServices.IViewService;

namespace Visual_Builder.ViewServices
{
    public class ServiceBase<T> : IServiceBase<T> where T : class
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public ServiceBase(IHttpClientFactory httpClientFactory, IHttpContextAccessor httpContextAccessor)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<bool> CreateAsync(string url, T objToCreate)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Add("x-api-key", SD.keyvalue);


                if (objToCreate != null)
                {
                    request.Content = new StringContent(JsonConvert.SerializeObject(objToCreate), Encoding.UTF8, "application/json");
                }

                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.SendAsync(request);
                if (response.StatusCode == System.Net.HttpStatusCode.Created)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
            
        }

        public async Task<bool> DeleteAsync(string url, int id)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Delete, url + id.ToString());
                request.Headers.Add("x-api-key", SD.keyvalue);


                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.SendAsync(request);
                if (response.StatusCode == System.Net.HttpStatusCode.NoContent)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
           
        }

        public async Task<IEnumerable<T>?> GetAllAsync(string url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                //request.Headers.Authorization= new AuthenticationHeaderValue(SD.keyvalue);
                request.Headers.Add("x-api-key", SD.keyvalue);
                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.SendAsync(request);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<IEnumerable<T>>(jsonString);
                }
                return null;
            }
            catch
            {
                return null;
            }
            
        }
        public async Task<T> GetAll_Async(string url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                //request.Headers.Authorization= new AuthenticationHeaderValue(SD.keyvalue);
                request.Headers.Add("x-api-key", SD.keyvalue);
                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.SendAsync(request);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                   var data= jsonString.ToList();
                    var res=  JsonConvert.DeserializeObject<Root>(jsonString);
                    return null;
                }
                return null;
            }
            catch(Exception x)
            {
                return null;
            }
            
        }
        public class Root
        {
            public List<string> MyArray { get; set; }
        }
        public async Task<T?> GetAsync(string url, int id)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, url+id.ToString());
                request.Headers.Add("x-api-key", SD.keyvalue);

                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.SendAsync(request);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<T>(jsonString);
                }
                return null;
            }
            catch
            {
                return null;
            }
            
        }

        public async Task<IEnumerable<T>?> GetbyId(string url, int id)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, url + id.ToString());
                request.Headers.Add("x-api-key", SD.keyvalue);


                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage responseMessage = await client.SendAsync(request);
                if (responseMessage.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var jsonstring = await responseMessage.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<IEnumerable<T>>(jsonstring);
                }
                return null;
            }
            catch
            {
                return null;
            }
            
        }

        public async Task<IEnumerable<T>?> GetlistAsync(string url, int id)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, url + id.ToString());
                request.Headers.Add("x-api-key", SD.keyvalue);

                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.SendAsync(request);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<IEnumerable<T>>(jsonString);
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<IEnumerable<T>?> postAsync(string url, T objToPost)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Add("x-api-key", SD.keyvalue);


                if (objToPost != null)
                {
                    request.Content = new
                    StringContent(JsonConvert.SerializeObject(objToPost), Encoding.UTF8, "application/json");
                }
                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.SendAsync(request);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {

                    var jsonstring = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<IEnumerable<T>>(jsonstring);
                }

                else
                {
                    return null;

                }
            }
            catch
            {
                return null;
            }
        }

        public async Task<bool> UpdateAsync(string url, T objToUpate)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Put, url);
                request.Headers.Add("x-api-key", SD.keyvalue);

                if (objToUpate != null)
                {
                    request.Content = new
                    StringContent(JsonConvert.SerializeObject(objToUpate), Encoding.UTF8, "application/json");
                }
                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.SendAsync(request);
                if (response.StatusCode == System.Net.HttpStatusCode.NoContent)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
            
        }

        public async Task<bool> UpSert(string url, T objToPost)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Add("x-api-key", SD.keyvalue);


                if (objToPost != null)
                {
                    request.Content = new
                    StringContent(JsonConvert.SerializeObject(objToPost), Encoding.UTF8, "application/json");
                }
                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.SendAsync(request);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {

                    var jsonstring = await response.Content.ReadAsStringAsync();
                    return true;
                }

                else
                {
                    return false;

                }
            }
            catch
            {
                return false;
            }
        }
    }
}
