﻿using System.Diagnostics;
using System.Net.Http;
using Visual_Builder.Models;
using Visual_Builder.ViewServices.IViewService;

namespace Visual_Builder.ViewServices
{
    public class StepViewService : ServiceBase<Step>, IStepViewService
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public StepViewService(IHttpClientFactory httpClientFactory, IHttpContextAccessor httpContextAccessor) : base(httpClientFactory, httpContextAccessor)
        {
            _httpClientFactory = httpClientFactory;
        }

    }
}
