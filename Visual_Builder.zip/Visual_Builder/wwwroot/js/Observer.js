﻿//var componentref;
//window.Objserver = {

//    observer: null,
//    Initialize: function (component, objserverTargetId) {
//        componentref = component;
//        this.observer = new IntersectionObserver(e => {
//            componentref.invokeMethodAsync('OnIntersection');

//        });
//        let element = document.getElementById(objserverTargetId);
//        $("#mydiv").scroll(function (e) {
//            console.log($('#mydiv').scrollTop())
//        });
//        if (element == null) throw new Error("Target was not found");
//        this.observer.observe(element);
//    }
//};

function openNav() {
    document.getElementById("mySidenav").style.width = "250px";

    var answerText = document.querySelectorAll("#answer");
    for (var i = 0; i < answerText.length; i++) {
        answerText[i].style.display = "inline";

    }
    
}
$(document).ready(function () {
    const password = document.getElementById('diagram-space');
    password.addEventListener('blur', (event) => {
        closeNav();
    });
});

function closeNav() {
    document.getElementById("mySidenav").style.width = "40px";

    var answerText = document.querySelectorAll("#answer");
    for (var i = 0; i < answerText.length; i++) {
        answerText[i].style.display = "none";

    }
}

function clicked() {
    var answerText = document.getElementById("answer");
    answerText.style.display = "none";
}